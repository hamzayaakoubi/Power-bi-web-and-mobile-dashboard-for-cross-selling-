# Power bi web and mobile dashboard for cross selling 
 Power bi web and mobile dashboard for cross selling for cross selling using python ,DAX  and power query
